import numpy as np
import math
import sys
import scipy
from scipy import integrate
from scipy import special
import functions
import cmath


#### mathematical functions ####
def kernelFOnsager(phi,phiPrime, p):
    def besselFactor(p,phi,phiPrime):
        return scipy.special.iv(0,p*np.sin(phi)*np.sin(phiPrime))
    return p/( np.sinh(p))*np.cosh(p*np.cos(phi)*np.cos(phiPrime))*besselFactor(p,phi,phiPrime)

def kernelFPoisson(phi, phiPrime, p):
    x = np.cos(phi)*np.cos(phiPrime)
    y = np.sin(phi)*np.sin(phiPrime)
    term1 = (1+p+2.*cmath.sqrt(p)*x)**2 - 4*p*y**2
    term2 = (1+p-2.*cmath.sqrt(p)*x)**2 - 4*p*y**2
    factor = cmath.sqrt(p)/(2.*np.arctanh(cmath.sqrt(p)))
    return (factor * (1./cmath.sqrt(term1) + 1./cmath.sqrt(term2))).real

def kernelFEqMSdecoupled(phi, phiPrime, p):  # decoupled Maier-Saupe for Eq peaks
    if round(phiPrime,4) != round(math.pi/2.,4):
        print 'Problem! Using wrong kernel function.'
    sqrtp = cmath.sqrt(p)
    c = 2.*sqrtp/(math.pi**.5 * scipy.special.erfi(sqrtp))
    return c * np.exp(p/2. * np.sin(phi)**2) * scipy.special.i0(p/2. * np.sin(phi)**2)

def kernelFEqMS(phi, phiPrime, p, c): # Maier-Saupe for equatorial peak -- See Burger et al equation 6-17
    def besselFactor(p,phi,phiPrime):
        return scipy.special.iv(0, .5 * p * math.sin(phi)**2)
    x = np.cos(phi)*np.cos(phiPrime)
    y = np.sin(phi)*np.sin(phiPrime)
    x2 = np.square(x)
    xy = x*y
    y2 = np.square(y)
    factor1 = c * np.exp(p* (x2 + y2/2.) )
    term1 = scipy.special.iv(0, 2.*p*xy) * scipy.special.iv(0, p*y2/2.)
    term2 = 0
    for i in range(1,4):
        term2 += 2. * scipy.special.iv(2*i, 2.*p*xy) * scipy.special.iv(i, p*y2/2)
    factor2 = term1 + term2
    return abs((factor1*factor2).real)

def lorentzian(q, qstar, b):
    b2 = b**2
    return b2 / ((q-qstar)**2 + b2)
def gaussian(q, qstar, b):
    square_part = ( (q-qstar)/(b/1.18) )**2
    return np.exp( -square_part/2. )
def doubleGaussian(q12, q3, qstar12, qstar3, b12, b3):
    exp1 = -((q12-qstar12)/b12)**2 /2.
    exp2 = -((q3-qstar3)/b3)**2 /2.
    return np.exp( exp1 + exp2 )

# cutoff lorentzian
def lorentzianCutoff(q, pos, b, cutoff_q, m):
    rel_q = q-pos 
    return max(np.absolute(rel_q)*m + 1/(1+cutoff_q**2) - m*cutoff_q*b, 0)

def idealPeakPolar(q, phi, b12, b3, qstar):
    q12 = q*np.sin(phi)
    q3  = q*np.cos(phi)
    return doubleGaussian(q12, q3, 0, qstar, b12, b3)

def idealPeakPolarL(q, phi, b12, b3, qstar): # Lorentzian in x and y
    q12 = q*np.sin(phi)
    q3  = q*np.cos(phi)
    return lorentzian(q12, 0, b12) * lorentzian(q3, qstar, b3)

def idealPeakPolar2(q, phi, b12, b3, qstar): # Lorentzian in x, Gaussian in y
    q12 = q*np.sin(phi)
    q3  = q*np.cos(phi)
    return lorentzian(q12, 0, b12) * gaussian(q3, qstar, b3)

def idealPeakPolar3(q, phi, b12, b3, qstar): # Lorentzian in x, Voigt in y
    q12 = q*np.sin(phi)
    q3  = q*np.cos(phi)
    voigt_gau_weight = .5
    voigt_lor_weight = .5
    voigt = voigt_gau_weight*gaussian(q3, qstar, b3) + voigt_lor_weight*lorentzian(q3, qstar, b3)
    return voigt*lorentzian(q12, 0, b12)

def idealPeakPolar4(q, phi, b12, b3, qstar): # Gaussian in x, cutoff-Lorentzian in y
    q12 = q*np.sin(phi)
    q3  = q*np.cos(phi)
    cutoff_q = 5.
    m = -2.*b3**2*(cutoff_q*b3)/(b3**2 + (cutoff_q*b3)**2)**2

    lor_cutoff_val = 0
    if abs(q-qstar) >= cutoff_q*b3:
        lor_cutoff_val = lorentzianCutoff(q, qstar, b3, cutoff_q, m)
    if abs(q-qstar) < cutoff_q*b3:
        lor_cutoff_val = lorentzian(q, qstar, b3)
    
    #lor_w_cutoff = np.piecewise(np.array(q),
    #                            [abs(q) < cutoff_q*b3 - m/(1+cutoff_q**2),   abs(q) >= cutoff_q*b3,   abs(q) < cutoff_q*b3],
    #                            [zero(q),   lorentzianCutoff(q, qstar, b3, cutoff_q),   lorentzian(q, qstar, b3)])
    return gaussian(q12, 0, b12) * lor_cutoff_val
    


#### functions for classes ####

def functionSummary(funcclassobj):
    params = []
    for i, name in enumerate(funcclassobj.param_names):
        s = '%s=%.4E' % (name, getattr(funcclassobj, name))
        if funcclassobj.fixed[i]: s = '*' + s
        params.append(s)
    return params

def getFunctionBounds(funcclassobj):
    params = []
    for i, name in enumerate(funcclassobj.parameters):
        s = '%s %s < %.4E < %s' % (name, funcclassobj.bounds[i][0], getattr(funcclassobj,name), funcclassobj.bounds[i][1])
        if funcclassobj.fixed[i]: s = '*' + s
        params.append(s)
    return params


#### classes ####
                      #######################################################################################
class peaktype1:   ## meridional peak, 2D gaussian smeared over Onsager distribution

    def __init__(self):
        self.func_no = None

        self.param_names = ['intensity', 'wx', 'wy', 'qstar', 'p']
        self.param_stepsize = [50, .01, .001, .001, 1]
        self.intensity, self.wx, self.wy, self.qstar, self.p = 1, .36, .03, .25, 40
        self.fixed = [False, False, False, False, False]
        self.override_qmin, self.override_qmax, self.override_phimin = None, None, None
        
        self.bounds = [ [0,1e6],
                        [0, 2],
                        [0, 2],
                        [0, 1],
                        [0, 100] ]

        # save time by storing previous calculation
        self.previous_data = None
        self.previous_params = None

    def sameAsPreviousData(self, q, phi): # check if this calculation is identical to the previous one
        if [getattr(self, ea) for ea in self.param_names] == self.previous_params:
            if np.array_equal(q, self.previous_data[0]) and np.array_equal(phi, self.previous_data[1]):
                return True

    def getQIntegrationLimits(self):
        # for smeared gaussian
        qmin = self.qstar - self.wy*2.5
        qmax = self.qstar + self.wy*8.
        return qmin, qmax
    def getPhiIntegrationLimits(self, qmin):
        # for onsager
        #print 3*self.wx/qmin
        phimin = math.pi/2 - math.atan(3*self.wx/qmin)
        #print phimin
        return phimin


    def optimizeIntensity(self, exp_data, other_fit_data, q, phi):
        
        def checkFit(other_fit_data, exp_data, cur_ssd, multiplier): # returns true if fit improved
            new_fit = other_fit_data + self.previous_data[2]*multiplier
            new_ssd = np.sum(np.square(exp_data - new_fit))
            if new_ssd < cur_ssd:
                return True
                self.intensity = self.intensity*multiplier
            
        if self.sameAsPreviousData(q, phi):
            cur_fit = other_fit_data + self.previous_data[2]
            cur_ssd = np.sum(np.square(exp_data - cur_fit))
            for mult in [1.04]*10 + [0.96]*10 + [1.003]*10 + [0.997]*10:
                if checkFit(other_fit_data, exp_data, cur_ssd, mult):
                    self.intensity = self.intensity*mult


    def calcSelf(self, q, phi):
        def integrand(phiPrime, q, phi, wx, wy, qstar, p):
            return idealPeakPolar(q, phiPrime, wx, wy, qstar)*kernelFOnsager(phi, phiPrime, p)*np.sin(phiPrime)

        quadresult_array = np.zeros(q.shape)
        
        qmin, qmax = self.getQIntegrationLimits()
        if self.override_qmin: qmin = self.override_qmin
        if self.override_qmax: qmax = self.override_qmax
        phimin = self.getPhiIntegrationLimits(qmin)
        if self.override_phimin: phimin = self.override_phimin

        # first check if any q,phi values are within this function's range (if not, don't bother)
        for i in range(q.shape[0]):
            if (qmin < q[i] < qmax) and (phi[i] > phimin):
                break
            if i == range(q.shape[0])[-1]:
                return np.zeros(q.shape)

        # next check if calculation has already been done
        if self.sameAsPreviousData(q, phi):
            return self.previous_data[2]

        # if not, calculate...
        for i in range(q.shape[0]):       # calc integral if within range #
            if (qmin < q[i] < qmax) and (phi[i] > phimin):
                # try numerical integration......
                phiPrimeForSimps = np.linspace(0,math.pi/2,1001,endpoint=True)
                array_to_integrate = integrand(phiPrimeForSimps, q[i], phi[i], self.wx, self.wy, self.qstar, self.p)
                simpsresult = integrate.simps(array_to_integrate, phiPrimeForSimps)
                quadresult = (simpsresult,)

                #quadresult = integrate.quad(integrand, 0, math.pi/2., epsrel=.01, epsabs=0,
                #                                  args=(q[i], phi[i], self.wx, self.wy, self.qstar, self.p))
            else:                         # otherwise return zero #
                quadresult = (0,)
            quadresult_array[i] = quadresult[0]
        quadresult_array = quadresult_array*self.intensity

        # remember data and parameters for next time
        self.previous_params = [getattr(self, ea) for ea in self.param_names]
        self.previous_data = np.array([q, phi, quadresult_array])
        
        print '\r',
        return quadresult_array
 
    def printSelf(self):
        params = [self.intensity, self.wx, self.wy, self.qstar, self.p]
        return 'peaktype1:\t' + '  '.join(functionSummary(self))


# Lorentzian in x and y, Maier-Saupe orientation distribution
class peaktype1eq:      #######################################################################################
    func_no = None
    param_names = ['intensity', 'wx', 'wy', 'qstar', 'p']
    param_stepsize = [100, .001, .003, .001, 1]
    intensity, wx, wy, qstar, p = 2000, .36, .03, 1.5, -10
    fixed = [False, False, False, False, False]
    bounds = [ [0,1e6],
               [0, 2],
               [0, 2],
               [0, 1],
               [0, 100] ]

    # save time by storing previous calculation
    previous_data = None
    previous_params = None

    def sameAsPreviousData(self, q, phi): # check if this calculation is identical to the previous one
        if [getattr(self, ea) for ea in self.param_names] == self.previous_params:
            if np.array_equal(q, self.previous_data[0]) and np.array_equal(phi, self.previous_data[1]):
                return True

    def getQIntegrationLimits(self):
        # for smeared gaussian
        qmin = self.qstar - self.wy*7.
        qmax = self.qstar + self.wy*6.
        return qmin, qmax
    def getPhiIntegrationLimits(self, qmin):
        # for Meier-Saupe
        phimin = 0#math.pi/2 - math.atan(3*self.wx/qmin)
        return phimin

    def calcSelf(self, q, phi):
        c = 2. * cmath.sqrt(self.p/math.pi) / scipy.special.erfi(cmath.sqrt(self.p)) # Meier-Saupe "C" 
        def integrandEq(phiPrime, q, phi, wx, wy, qstar, kernel_interp):
            return idealPeakPolarL(q, phiPrime, wx, wy, qstar) * kernel_interp(phiPrime) * math.sin(phiPrime)

        quadresult_array = np.zeros(q.shape)
        qmin, qmax = self.getQIntegrationLimits()
        phimin = self.getPhiIntegrationLimits(qmin)

        # first check if any q,phi values are within this function's range (if not, don't bother)
        for i in range(q.shape[0]):
            if (qmin < q[i] < qmax) and (phi[i] > phimin):
                break
            if i == range(q.shape[0])[-1]:
                return np.zeros(q.shape)

        # next check if calculation has already been done
        if self.sameAsPreviousData(q, phi):
            return self.previous_data[2]

        ##### if not, calculate...
        
        # calculate kernel for each phi
        phi_reduced = np.around(np.copy(phi),2)
        #print 'Getting kernel interpolations'
        phiPrime_for_kernel_calculation = np.linspace(0, math.pi/2., 50)
        phi_key, kernel_interp_li = functions.getMaierSaupeEqKernel(phi_reduced, self.p, phiPrime_for_kernel_calculation)
        #print 'Got kernel interpolations'

        
        for i in range(q.shape[0]):       # calc integral if within range #
            if (qmin < q[i] < qmax) and (phi_reduced[i] > phimin):                
                if i != 0 and q.shape[0]%i == 0:
                    cur_pct = round(float(i)/q.shape[0],2)*100
                    if cur_pct >= 10:
                        pass#print cur_pct, '%',
                        
                # calculate integral
                kernel_interp = kernel_interp_li[phi_key.index(phi_reduced[i])]
                quadresult = integrate.quad(integrandEq, 0, math.pi/2., epsabs=0, epsrel=1e-1,
                                                  args=(q[i], phi_reduced[i], self.wx, self.wy, self.qstar, kernel_interp))
            else:                         # otherwise return zero #
                quadresult = (0,)
            quadresult_array[i] = quadresult[0]
        quadresult_array = quadresult_array*self.intensity

        # remember data and parameters for next time
        self.previous_params = [getattr(self, ea) for ea in self.param_names]
        self.previous_data = np.array([q, phi, quadresult_array])
        
        print '\r',
        return quadresult_array

    def printSelf(self):
        params = [self.intensity, self.wx, self.wy, self.qstar, self.p]
        return 'peaktype1eq:\t' + '  '.join(functionSummary(self))

# Lorentzian in x, Gaussian in y, Maier-Saupe orientation distribution
class peaktype2eq:      #######################################################################################
    func_no = None
    param_names = ['intensity', 'wx', 'wy', 'qstar', 'p']
    param_stepsize = [100, .001, .003, .001, 1]
    intensity, wx, wy, qstar, p = 2000, .36, .03, 1.5, -10
    fixed = [False, False, False, False, False]
    bounds = [ [0,1e6],
               [0, 2],
               [0, 2],
               [0, 1],
               [0, 100] ]

    # save time by storing previous calculation
    previous_data = None
    previous_params = None

    def sameAsPreviousData(self, q, phi): # check if this calculation is identical to the previous one
        if [getattr(self, ea) for ea in self.param_names] == self.previous_params:
            if np.array_equal(q, self.previous_data[0]) and np.array_equal(phi, self.previous_data[1]):
                return True

    def getQIntegrationLimits(self):
        # for smeared gaussian
        qmin = self.qstar - self.wy*40.
        qmax = self.qstar + self.wy*40.
        return qmin, qmax
    def getPhiIntegrationLimits(self, qmin):
        # for Meier-Saupe
        phimin = 0#math.pi/2 - math.atan(3*self.wx/qmin)
        return phimin

    def calcSelf(self, q, phi):
        c = 2. * cmath.sqrt(self.p/math.pi) / scipy.special.erfi(cmath.sqrt(self.p)) # Meier-Saupe "C" 
        def integrandEq(phiPrime, q, phi, wx, wy, qstar, kernel_interp):
            return idealPeakPolar2(q, phiPrime, wx, wy, qstar) * kernel_interp(phiPrime) * math.sin(phiPrime)

        quadresult_array = np.zeros(q.shape)
        qmin, qmax = self.getQIntegrationLimits()
        phimin = self.getPhiIntegrationLimits(qmin)

        # first check if any q,phi values are within this function's range (if not, don't bother)
        for i in range(q.shape[0]):
            if (qmin < q[i] < qmax) and (phi[i] > phimin):
                break
            if i == range(q.shape[0])[-1]:
                return np.zeros(q.shape)

        # next check if calculation has already been done
        if self.sameAsPreviousData(q, phi):
            return self.previous_data[2]

        ##### if not, calculate...
        
        # calculate kernel for each phi
        phi_reduced = np.around(np.copy(phi),2)
        #print 'Getting kernel interpolations'
        phiPrime_for_kernel_calculation = np.linspace(0, math.pi/2., 50)
        phi_key, kernel_interp_li = functions.getMaierSaupeEqKernel(phi_reduced, self.p, phiPrime_for_kernel_calculation)
        #print 'Got kernel interpolations'

        
        for i in range(q.shape[0]):       # calc integral if within range #
            if (qmin < q[i] < qmax) and (phi_reduced[i] > phimin):                
                if i != 0 and q.shape[0]%i == 0:
                    cur_pct = round(float(i)/q.shape[0],2)*100
                    if cur_pct >= 10:
                        pass#print cur_pct, '%',
                        
                # calculate integral
                kernel_interp = kernel_interp_li[phi_key.index(phi_reduced[i])]
                quadresult = integrate.quad(integrandEq, 0, math.pi/2., epsabs=0, epsrel=1e-1,
                                                  args=(q[i], phi_reduced[i], self.wx, self.wy, self.qstar, kernel_interp))
            else:                         # otherwise return zero #
                quadresult = (0,)
            quadresult_array[i] = quadresult[0]
        quadresult_array = quadresult_array*self.intensity

        # remember data and parameters for next time
        self.previous_params = [getattr(self, ea) for ea in self.param_names]
        self.previous_data = np.array([q, phi, quadresult_array])
        
        print '\r',
        return quadresult_array

    def printSelf(self):
        params = [self.intensity, self.wx, self.wy, self.qstar, self.p]
        return 'peaktype1eq:\t' + '  '.join(functionSummary(self))

    # Lorentzian in x, 50/50Voigt in y, Maier-Saupe orientation distribution
class peaktype3eq:      #######################################################################################
    func_no = None
    param_names = ['intensity', 'wx', 'wy', 'qstar', 'p']
    param_stepsize = [100, .001, .003, .001, 1]
    intensity, wx, wy, qstar, p = 2000, .36, .03, 1.5, -10
    fixed = [False, False, False, False, False]
    bounds = [ [0,1e6],
               [0, 2],
               [0, 2],
               [0, 1],
               [0, 100] ]

    # save time by storing previous calculation
    previous_data = None
    previous_params = None

    def sameAsPreviousData(self, q, phi): # check if this calculation is identical to the previous one
        if [getattr(self, ea) for ea in self.param_names] == self.previous_params:
            if np.array_equal(q, self.previous_data[0]) and np.array_equal(phi, self.previous_data[1]):
                return True

    def getQIntegrationLimits(self):
        # for smeared gaussian
        qmin = self.qstar - self.wy*40.
        qmax = self.qstar + self.wy*40.
        return qmin, qmax
    def getPhiIntegrationLimits(self, qmin):
        # for Meier-Saupe
        phimin = 0#math.pi/2 - math.atan(3*self.wx/qmin)
        return phimin

    def calcSelf(self, q, phi):
        c = 2. * cmath.sqrt(self.p/math.pi) / scipy.special.erfi(cmath.sqrt(self.p)) # Meier-Saupe "C" 
        def integrandEq(phiPrime, q, phi, wx, wy, qstar, kernel_interp):
            return idealPeakPolar3(q, phiPrime, wx, wy, qstar) * kernel_interp(phiPrime) * math.sin(phiPrime)

        quadresult_array = np.zeros(q.shape)
        qmin, qmax = self.getQIntegrationLimits()
        phimin = self.getPhiIntegrationLimits(qmin)

        # first check if any q,phi values are within this function's range (if not, don't bother)
        for i in range(q.shape[0]):
            if (qmin < q[i] < qmax) and (phi[i] > phimin):
                break
            if i == range(q.shape[0])[-1]:
                return np.zeros(q.shape)

        # next check if calculation has already been done
        if self.sameAsPreviousData(q, phi):
            return self.previous_data[2]

        ##### if not, calculate...
        
        # calculate kernel for each phi
        phi_reduced = np.around(np.copy(phi),2)
        #print 'Getting kernel interpolations'
        phiPrime_for_kernel_calculation = np.linspace(0, math.pi/2., 50)
        phi_key, kernel_interp_li = functions.getMaierSaupeEqKernel(phi_reduced, self.p, phiPrime_for_kernel_calculation)
        #print 'Got kernel interpolations'

        
        for i in range(q.shape[0]):       # calc integral if within range #
            if (qmin < q[i] < qmax) and (phi_reduced[i] > phimin):                
                if i != 0 and q.shape[0]%i == 0:
                    cur_pct = round(float(i)/q.shape[0],2)*100
                    if cur_pct >= 10:
                        pass#print cur_pct, '%',
                        
                # calculate integral
                kernel_interp = kernel_interp_li[phi_key.index(phi_reduced[i])]
                quadresult = integrate.quad(integrandEq, 0, math.pi/2., epsabs=0, epsrel=1e-1,
                                                  args=(q[i], phi_reduced[i], self.wx, self.wy, self.qstar, kernel_interp))
            else:                         # otherwise return zero #
                quadresult = (0,)
            quadresult_array[i] = quadresult[0]
        quadresult_array = quadresult_array*self.intensity

        # remember data and parameters for next time
        self.previous_params = [getattr(self, ea) for ea in self.param_names]
        self.previous_data = np.array([q, phi, quadresult_array])
        
        print '\r',
        return quadresult_array

    def printSelf(self):
        params = [self.intensity, self.wx, self.wy, self.qstar, self.p]
        return 'peaktype3eq:\t' + '  '.join(functionSummary(self))

        # Gaussian in x, cutoff Lorentzian in y, Maier-Saupe orientation distribution
class peaktype4eq:      #######################################################################################
    func_no = None
    param_names = ['intensity', 'wx', 'wy', 'qstar', 'p']
    param_stepsize = [100, .001, .003, .001, 1]
    intensity, wx, wy, qstar, p = 2000, .36, .03, 1.5, -10
    fixed = [False, False, False, False, False]
    bounds = [ [0,1e6],
               [0, 2],
               [0, 2],
               [0, 1],
               [0, 100] ]

    # save time by storing previous calculation
    previous_data = None
    previous_params = None

    def sameAsPreviousData(self, q, phi): # check if this calculation is identical to the previous one
        if [getattr(self, ea) for ea in self.param_names] == self.previous_params:
            if np.array_equal(q, self.previous_data[0]) and np.array_equal(phi, self.previous_data[1]):
                return True

    def getQIntegrationLimits(self):
        # for smeared gaussian
        qmin = self.qstar - self.wy*40.
        qmax = self.qstar + self.wy*40.
        return qmin, qmax
    def getPhiIntegrationLimits(self, qmin):
        # for Meier-Saupe
        phimin = 0#math.pi/2 - math.atan(3*self.wx/qmin)
        return phimin

    def calcSelf(self, q, phi):
        c = 2. * cmath.sqrt(self.p/math.pi) / scipy.special.erfi(cmath.sqrt(self.p)) # Meier-Saupe "C" 
        def integrandEq(phiPrime, q, phi, wx, wy, qstar, kernel_interp):
            return idealPeakPolar4(q, phiPrime, wx, wy, qstar) * kernel_interp(phiPrime) * math.sin(phiPrime)

        quadresult_array = np.zeros(q.shape)
        qmin, qmax = self.getQIntegrationLimits()
        phimin = self.getPhiIntegrationLimits(qmin)

        # first check if any q,phi values are within this function's range (if not, don't bother)
        for i in range(q.shape[0]):
            if (qmin < q[i] < qmax) and (phi[i] > phimin):
                break
            if i == range(q.shape[0])[-1]:
                return np.zeros(q.shape)

        # next check if calculation has already been done
        if self.sameAsPreviousData(q, phi):
            return self.previous_data[2]

        ##### if not, calculate...
        
        # calculate kernel for each phi
        phi_reduced = np.around(np.copy(phi),2)
        #print 'Getting kernel interpolations'
        phiPrime_for_kernel_calculation = np.linspace(0, math.pi/2., 50)
        phi_key, kernel_interp_li = functions.getMaierSaupeEqKernel(phi_reduced, self.p, phiPrime_for_kernel_calculation)
        #print 'Got kernel interpolations'

        
        for i in range(q.shape[0]):       # calc integral if within range #
            if (qmin < q[i] < qmax) and (phi_reduced[i] > phimin):                
                if i != 0 and q.shape[0]%i == 0:
                    cur_pct = round(float(i)/q.shape[0],2)*100
                    if cur_pct >= 10:
                        pass#print cur_pct, '%',
                        
                # calculate integral
                kernel_interp = kernel_interp_li[phi_key.index(phi_reduced[i])]
                quadresult = integrate.quad(integrandEq, 0, math.pi/2., epsabs=0, epsrel=1e-1,
                                                  args=(q[i], phi_reduced[i], self.wx, self.wy, self.qstar, kernel_interp))
            else:                         # otherwise return zero #
                quadresult = (0,)
            quadresult_array[i] = quadresult[0]
        quadresult_array = quadresult_array*self.intensity

        # remember data and parameters for next time
        self.previous_params = [getattr(self, ea) for ea in self.param_names]
        self.previous_data = np.array([q, phi, quadresult_array])
        
        print '\r',
        return quadresult_array

    def printSelf(self):
        params = [self.intensity, self.wx, self.wy, self.qstar, self.p]
        return 'peaktype3eq:\t' + '  '.join(functionSummary(self))

# Gaussian in x and y, Maier-Saupe orientation distribution
class peaktype5eq:      #######################################################################################
    func_no = None
    param_names = ['intensity', 'wx', 'wy', 'qstar', 'p']
    param_stepsize = [4000, .001, .003, .001, 1]
    intensity, wx, wy, qstar, p = 2000, .36, .03, 1.5, -10
    fixed = [False, False, False, False, False]
    bounds = [ [0,1e6],
               [0, 2],
               [0, 2],
               [0, 1],
               [0, 100] ]

    # save time by storing previous calculation
    previous_data = None
    previous_params = None

    def sameAsPreviousData(self, q, phi): # check if this calculation is identical to the previous one
        if [getattr(self, ea) for ea in self.param_names] == self.previous_params:
            if np.array_equal(q, self.previous_data[0]) and np.array_equal(phi, self.previous_data[1]):
                return True

    def getQIntegrationLimits(self):
        # for smeared gaussian
        qmin = self.qstar - self.wy*3.5
        qmax = self.qstar + self.wy*4.
        return qmin, qmax
    def getPhiIntegrationLimits(self, qmin):
        # for Meier-Saupe
        phimin = 0#math.pi/2 - math.atan(3*self.wx/qmin)
        return phimin

    def optimizeIntensity(self, exp_data, other_fit_data, q, phi):
        
        def checkFit(other_fit_data, exp_data, cur_ssd, multiplier): # returns true if fit improved
            new_fit = other_fit_data + self.previous_data[2]*multiplier
            new_ssd = np.sum(np.square(exp_data - new_fit))
            if new_ssd < cur_ssd:
                return True
                self.intensity = self.intensity*multiplier
            
        if self.sameAsPreviousData(q, phi):
            cur_fit = other_fit_data + self.previous_data[2]
            cur_ssd = np.sum(np.square(exp_data - cur_fit))
            for mult in [1.1]*10 + [0.9]*10 + [1.01]*10 + [0.99]*10:
                if checkFit(other_fit_data, exp_data, cur_ssd, mult):
                    self.intensity = self.intensity*mult
         

    def calcSelf(self, q, phi):
        c = 2. * cmath.sqrt(self.p/math.pi) / scipy.special.erfi(cmath.sqrt(self.p)) # Meier-Saupe "C" 
        def integrandEq(phiPrime, q, phi, wx, wy, qstar, kernel_interp):
            return idealPeakPolar(q, phiPrime, wx, wy, qstar) * kernel_interp(phiPrime) * np.sin(phiPrime)

        quadresult_array = np.zeros(q.shape)
        qmin, qmax = self.getQIntegrationLimits()
        phimin = self.getPhiIntegrationLimits(qmin)

        # first check if any q,phi values are within this function's range (if not, don't bother)
        for i in range(q.shape[0]):
            if (qmin < q[i] < qmax) and (phi[i] > phimin):
                break
            if i == range(q.shape[0])[-1]:
                return np.zeros(q.shape)

        # next check if calculation has already been done
        if self.sameAsPreviousData(q, phi):
            return self.previous_data[2]

        ##### if not, calculate...
        
        # calculate kernel for each phi
        phi_reduced = np.around(np.copy(phi),2)
        #print 'Getting kernel interpolations'
        phiPrime_for_kernel_calculation = np.linspace(0, math.pi/2., 50)
        phi_key, kernel_interp_li = functions.getMaierSaupeEqKernel(phi_reduced, self.p, phiPrime_for_kernel_calculation)
        #print 'Got kernel interpolations'

        
        for i in range(q.shape[0]):       # calc integral if within range #
            if (qmin < q[i] < qmax) and (phi_reduced[i] > phimin):                
                if i != 0 and q.shape[0]%i == 0:
                    cur_pct = round(float(i)/q.shape[0],2)*100
                    if cur_pct >= 10:
                        pass#print cur_pct, '%',
                        
                # calculate integral
                kernel_interp = kernel_interp_li[phi_key.index(phi_reduced[i])]
                # try numerical integration......
                phiPrimeForSimps = np.linspace(0,math.pi/2,1001,endpoint=True)
                array_to_integrate = integrandEq(phiPrimeForSimps, q[i], phi_reduced[i], self.wx, self.wy, self.qstar, kernel_interp)
                simpsresult = integrate.simps(array_to_integrate, phiPrimeForSimps)
                quadresult = (simpsresult,)
                #quadresult = integrate.quad(integrandEq, 0, math.pi/2., epsabs=0, epsrel=1e-1,
                #                                  args=(q[i], phi_reduced[i], self.wx, self.wy, self.qstar, kernel_interp))
            else:                         # otherwise return zero #
                quadresult = (0,)
            quadresult_array[i] = quadresult[0]
        quadresult_array = quadresult_array*self.intensity

        # remember data and parameters for next time
        self.previous_params = [getattr(self, ea) for ea in self.param_names]
        self.previous_data = np.array([q, phi, quadresult_array])
        
        print '\r',
        return quadresult_array

    def printSelf(self):
        params = [self.intensity, self.wx, self.wy, self.qstar, self.p]
        return 'peaktype5eq:\t' + '  '.join(functionSummary(self))


# Equatorial peak, Gaussian in x and y, with Decoupled Onsager orientation distribution
class peaktype6eq:      #######################################################################################
    func_no = None
    param_names = ['intensity', 'wy', 'qstar', 'p']
    param_stepsize = [4000, .003, .001, 1]
    intensity, wy, qstar, p = 2000, .03, 1.5, -10
    fixed = [False, False, False, False]
    bounds = [ [0,1e6],
               [0, 2],
               [0, 1],
               [0, 100] ]

    # save time by storing previous calculation
    previous_data = None
    previous_params = None

    def sameAsPreviousData(self, q, phi): # check if this calculation is identical to the previous one
        if [getattr(self, ea) for ea in self.param_names] == self.previous_params:
            if np.array_equal(q, self.previous_data[0]) and np.array_equal(phi, self.previous_data[1]):
                return True

    def getQIntegrationLimits(self):
        # for smeared gaussian
        qmin = self.qstar - self.wy*3.5
        qmax = self.qstar + self.wy*4.
        return qmin, qmax
    def getPhiIntegrationLimits(self, qmin):
        # for Meier-Saupe
        phimin = 0#math.pi/2 - math.atan(3*self.wx/qmin)
        return 0

    def optimizeIntensity(self, exp_data, other_fit_data, q, phi):
        
        def checkFit(other_fit_data, exp_data, cur_ssd, multiplier): # returns true if fit improved
            new_fit = other_fit_data + self.previous_data[2]*multiplier
            new_ssd = np.sum(np.square(exp_data - new_fit))
            if new_ssd < cur_ssd:
                return True
                self.intensity = self.intensity*multiplier
            
        if self.sameAsPreviousData(q, phi):
            cur_fit = other_fit_data + self.previous_data[2]
            cur_ssd = np.sum(np.square(exp_data - cur_fit))
            for mult in [1.1]*10 + [0.9]*10 + [1.01]*10 + [0.99]*10:
                if checkFit(other_fit_data, exp_data, cur_ssd, mult):
                    self.intensity = self.intensity*mult
         

    def calcSelf(self, q, phi):
        result_array = np.zeros(q.shape)
        qmin, qmax = self.getQIntegrationLimits()
        phimin = self.getPhiIntegrationLimits(qmin)
        phimax = 100

        # first check if any q,phi values are within this function's range (if not, don't bother)
        for i in range(q.shape[0]):
            if (qmin < q[i] < qmax) and (phi[i] > phimin):
                break
            if i == range(q.shape[0])[-1]:
                return np.zeros(q.shape)

        # next check if calculation has already been done
        if self.sameAsPreviousData(q, phi):
            return self.previous_data[2]

        ##### otherwise, calculate...
        
        for i in range(q.shape[0]):       # calc integral if within range #
            result = gaussian(q[i], self.qstar, self.wy)/(2*self.wy) * kernelFOnsager(phi[i], math.pi/2., self.p)
            result_array[i] = result
        result_array = result_array*self.intensity

        # remember data and parameters for next time
        self.previous_params = [getattr(self, ea) for ea in self.param_names]
        self.previous_data = np.array([q, phi, result_array])
        return result_array

    def printSelf(self):
        params = [self.intensity, self.wy, self.qstar, self.p]
        return 'peaktype6eq:\t' + '  '.join(functionSummary(self))


# Equatorial peak, Gaussian in x and y, with Decoupled Maier-Saupe orientation distribution
class peaktype7eq:      #######################################################################################
    func_no = None
    param_names = ['intensity', 'wy', 'qstar', 'p']
    param_stepsize = [4000, .003, .001, 1]
    intensity, wy, qstar, p = 2000, .03, 1.5, -10
    fixed = [False, False, False, False]
    bounds = [ [0,1e6],
               [0, 2],
               [0, 1],
               [0, 100] ]

    # save time by storing previous calculation
    previous_data = None
    previous_params = None

    def sameAsPreviousData(self, q, phi): # check if this calculation is identical to the previous one
        if [getattr(self, ea) for ea in self.param_names] == self.previous_params:
            if np.array_equal(q, self.previous_data[0]) and np.array_equal(phi, self.previous_data[1]):
                return True

    def getQIntegrationLimits(self):
        # for smeared gaussian
        qmin = self.qstar - self.wy*3.5
        qmax = self.qstar + self.wy*4.
        return qmin, qmax
    def getPhiIntegrationLimits(self, qmin):
        # for Meier-Saupe
        phimin = 0#math.pi/2 - math.atan(3*self.wx/qmin)
        return 0

    def optimizeIntensity(self, exp_data, other_fit_data, q, phi):
        
        def checkFit(other_fit_data, exp_data, cur_ssd, multiplier): # returns true if fit improved
            new_fit = other_fit_data + self.previous_data[2]*multiplier
            new_ssd = np.sum(np.square(exp_data - new_fit))
            if new_ssd < cur_ssd:
                return True
                self.intensity = self.intensity*multiplier
            
        if self.sameAsPreviousData(q, phi):
            cur_fit = other_fit_data + self.previous_data[2]
            cur_ssd = np.sum(np.square(exp_data - cur_fit))
            for mult in [1.1]*10 + [0.9]*10 + [1.01]*10 + [0.99]*10:
                if checkFit(other_fit_data, exp_data, cur_ssd, mult):
                    self.intensity = self.intensity*mult
         

    def calcSelf(self, q, phi):
        result_array = np.zeros(q.shape)
        qmin, qmax = self.getQIntegrationLimits()
        phimin = self.getPhiIntegrationLimits(qmin)
        phimax = 100

        # first check if any q,phi values are within this function's range (if not, don't bother)
        for i in range(q.shape[0]):
            if (qmin < q[i] < qmax) and (phi[i] > phimin):
                break
            if i == range(q.shape[0])[-1]:
                return np.zeros(q.shape)

        # next check if calculation has already been done
        if self.sameAsPreviousData(q, phi):
            return self.previous_data[2]

        ##### otherwise, calculate...
        
        for i in range(q.shape[0]):       # calc integral if within range #
            result = gaussian(q[i], self.qstar, self.wy)/(2*self.wy) * kernelFEqMSdecoupled(phi[i], math.pi/2., self.p)
            result_array[i] = result
        result_array = result_array*self.intensity

        # remember data and parameters for next time
        self.previous_params = [getattr(self, ea) for ea in self.param_names]
        self.previous_data = np.array([q, phi, result_array])
        return result_array

    def printSelf(self):
        params = [self.intensity, self.wy, self.qstar, self.p]
        return 'peaktype7eq:\t' + '  '.join(functionSummary(self))


class amorphhaloL:  ## Lorentzian ########################################################################
    func_no = None
    param_names = ['intensity', 'qstar', 'w']
    param_stepsize = [10., .002, .002]
    intensity, qstar, w = 1., 1.3, .3
    fixed = [False, False, False]
    bounds = [ [0,5], [1,1.5], [.05,.5] ]
    
    def getQIntegrationLimits(self):
        dq = 3.*self.w
        return self.qstar - dq, self.qstar + dq
    def getPhiIntegrationLimits(self, qmin):
        return 0 # minimum phi

    def optimizeIntensity(self, exp_data, other_fit_data, q, phi):
        
        def checkFit(other_fit_data, exp_data, cur_ssd, multiplier): # returns true if fit improved
            new_fit = other_fit_data + self.previous_data[2]*multiplier
            new_ssd = np.sum(np.square(exp_data - new_fit))
            if new_ssd < cur_ssd:
                return True
                self.intensity = self.intensity*multiplier
            
        if self.sameAsPreviousData(q, phi):
            cur_fit = other_fit_data + self.previous_data[2]
            cur_ssd = np.sum(np.square(exp_data - cur_fit))
            for mult in [1.04]*10 + [0.96]*10 + [1.003]*10 + [0.997]*10:
                if checkFit(other_fit_data, exp_data, cur_ssd, mult):
                    self.intensity = self.intensity*mult

    def calcSelf(self, q, phi):
        def lorentzian(q, pos, kappa):
            return np.divide(kappa**2, np.square(q-pos) + kappa**2)
        return lorentzian(q, self.qstar, self.w) * self.intensity
    def printSelf(self):
        params = [self.intensity, self.qstar, self.w]
        return 'amorphhaloL:\t' + '  '.join(functionSummary(self))


class amorphhaloL2:  ## Lorentzian w/ Maier-Saupe phi dependence ################################################################
    func_no = None
    param_names = ['intensity', 'qstar', 'w', 'p']
    param_stepsize = [10., .002, .002, 1]
    intensity, qstar, w, p = 1., 1.3, .3, -20
    fixed = [False, False, False, False]
    bounds = [ [0,5], [1,1.5], [.05,.5], [-100,100] ]
    
    def getQIntegrationLimits(self):
        dq = 3.*self.w
        return self.qstar - dq, self.qstar + dq
    def getPhiIntegrationLimits(self, qmin):
        return 0 # minimum phi

    def optimizeIntensity(self, exp_data, other_fit_data, q, phi):
        
        def checkFit(other_fit_data, exp_data, cur_ssd, multiplier): # returns true if fit improved
            new_fit = other_fit_data + self.previous_data[2]*multiplier
            new_ssd = np.sum(np.square(exp_data - new_fit))
            if new_ssd < cur_ssd:
                return True
                self.intensity = self.intensity*multiplier
            
        if self.sameAsPreviousData(q, phi):
            cur_fit = other_fit_data + self.previous_data[2]
            cur_ssd = np.sum(np.square(exp_data - cur_fit))
            for mult in [1.04]*10 + [0.96]*10 + [1.003]*10 + [0.997]*10:
                if checkFit(other_fit_data, exp_data, cur_ssd, mult):
                    self.intensity = self.intensity*mult

    def calcSelf(self, q, phi):
        def odf(phi, p):
            c = 2*cmath.sqrt(p/math.pi)/scipy.special.erfi(cmath.sqrt(p))
            return (c*np.exp(p*np.square(np.cos(phi)))).real
        def lorentzian(q, pos, kappa):
            return np.divide(kappa**2, np.square(q-pos) + kappa**2)
        return lorentzian(q, self.qstar, self.w) * odf(phi, self.p) * self.intensity
    def printSelf(self):
        params = [self.intensity, self.qstar, self.w, self.p]
        return 'amorphhaloL2:\t' + '  '.join(functionSummary(self))



    
class flatbgnd:      #######################################################################################
    func_no = None
    param_names = ['intensity']
    param_stepsize = [.005]
    intensity = .1
    fixed = [False]
    bounds = [ [0,1e6] ]
    def getQIntegrationLimits(self):
        return 0,100
    def getPhiIntegrationLimits(self, qmin):
        return 0 # minimum phi

    def optimizeIntensity(self, exp_data, other_fit_data, q, phi):
        
        def checkFit(other_fit_data, exp_data, cur_ssd, multiplier): # returns true if fit improved
            new_fit = other_fit_data + self.previous_data[2]*multiplier
            new_ssd = np.sum(np.square(exp_data - new_fit))
            if new_ssd < cur_ssd:
                return True
                self.intensity = self.intensity*multiplier
            
        if self.sameAsPreviousData(q, phi):
            cur_fit = other_fit_data + self.previous_data[2]
            cur_ssd = np.sum(np.square(exp_data - cur_fit))
            for mult in [1.04]*10 + [0.96]*10 + [1.003]*10 + [0.997]*10:
                if checkFit(other_fit_data, exp_data, cur_ssd, mult):
                    self.intensity = self.intensity*mult

    def calcSelf(self, q, phi):
        return np.full(q.shape, self.intensity)
    def printSelf(self):
        params = [self.intensity]
        return 'flatbgnd:\t' + '  '.join(functionSummary(self))


################################# PROGRAM STATUS #######################################################

class program_status:
    #def __init__(self):
    # loaded data #
    cur_files = None
    cur_fit = None
    heads = None
    xray_data = None
    # fitting #
    fit_functions = []
    fit_range = [0,2,0,2.*math.pi] # q, phi
    plot_fitlim = False
    # plotting #
    plt_commands = []
    vmin, vmax = 0, 1e4
    vmin_diff, vmax_diff = None, None
    cmap = 'Set1'
    def vrangeDiff(self):
        vmin, vmax = self.vmin, self.vmax
        return -(vmax-vmin)/2., (vmax-vmin)/2.
    cmap_diff = 'seismic'
    # commands #
    command_history = []
    def printStatus(self):
        printlines = ['-----------------------------------------------------------',
                      'File: %s'    % (str(self.cur_files)),
                      'Fit_functions:', 
                      '%s\n'                     % ('\n'.join(['\t%d. %s' % (i, ea.printSelf()) for i, ea in enumerate(self.fit_functions)]))
                      #'Fit_options:',
                      #'\tFit range: q:(%1.3f, %1.3f) phi:(%d, %d)' % (self.fit_range[0][0], self.fit_range[0][1],
                      #                                                self.fit_range[1][0]*180./math.pi, self.fit_range[1][1]*180./math.pi),
                      #'plt_commands:',
                      #'%s'                      % ('\n'.join(['\t%d. %s' % (i, c) for i, c in enumerate(self.plt_commands)]))
                      ]
        print '\n'.join(printlines)
    def saveStatus(self):
        lines = ['File: %s'    % (str(self.cur_files)),
                 'Fit_functions:', 
                 '%s'                     % ('\n'.join(['%d. %s' % (i, ea.printSelf()) for i, ea in enumerate(self.fit_functions)])),
                 'Fit_options:',
                 'Fit range: (%s, %s)' % (str(self.fit_range[0]), str(self.fit_range[1])),
                 'plt_commands:',
                 '%s'                     % ('\n'.join(['%d. %s' % (i, c) for i, c in enumerate(self.plt_commands)]))]
        return '\n'.join(lines)
    def getStatusFromFile(self, filepath, nofile):
        f = open(filepath, 'r')
        lines = f.read().split('\n')
        f.close()
        
        # get file list unless nofile
        if not nofile:
            tmp, file_basename, phi1_li, phi2_li = lines.pop(0).split(' ')
            self.cur_files = '%s %s %s' % (file_basename, phi1_li, phi2_li)
            exec('phi1_li = %s' % phi1_li)
            exec('phi2_li = %s' % phi2_li)
            files = [file_basename + '_chi%d.0-%d.0.txt' % (phi1, phi2) for phi1, phi2 in zip(phi1_li,phi2_li)]
            phi_li = [.5*(phi1+phi2)*math.pi/180. for phi1, phi2 in zip(phi1_li,phi2_li)]

            # get data
            q, phi, I = functions.getDataFromFiles(files, phi_li)
            self.xray_data = np.array([q, phi, I])

        # get fits etc
        fit_functions_index = lines.index('Fit_functions:')
        fit_options_index = lines.index('Fit_options:')
        plt_commands_index = lines.index('plt_commands:')

        self.fit_functions = []
        for i in range(fit_functions_index+1, fit_options_index):
            line = lines[i].split()
            fitfunc = line[1].rstrip(':')
            exec 'fitfunc = %s()' % (fitfunc)
            #print line
            for j, ea in enumerate(fitfunc.param_names):
                #print '*** param loop ', j
                #print ea
                #print line
                #print line[2+j]
                setattr(fitfunc, ea, float(line[2+j].split('=')[1]))
            self.fit_functions.append(fitfunc)

        for i in range(fit_options_index+1, plt_commands_index):
            if lines[i].startswith('Fit limits'):
                self.fit_range[0] = float(lines[i].split('(')[1].split(',')[0])
                self.fit_range[1] = float(lines[i].split(', ')[1].rstrip(')'))

        self.plt_commands = []
        for i in range(plt_commands_index+1, len(lines)):
            if lines[i]:
                self.plt_commands.append(lines[i])
        #print self.heads

