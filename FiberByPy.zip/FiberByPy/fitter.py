import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.optimize import leastsq
import datetime
import time
import sys
import classes


def limitRange(f, limits, e1=None, e2=None):
    if limits[0] is None:
        limits[0] = float("-inf")
    if limits[1] is None:
        limits[1] = float("inf")
    new_f = []
    if e1 and e2:
        new_e1 = []
        new_e2 = []
    for i in range(f.size):
        if f[i] > limits[0] and f[i] < limits[1]:
            new_f.append(f[i])
            if e1 and e2:
                new_e1.append(e1[i])
                new_e2.append(e2[i])
    if e1 and e2:
        return np.array(new_f), np.array(new_e1), np.array(new_e2)
    return np.array(new_f)


def calculateFit(fit_functions, xray_data, status):
    q, phi, I = xray_data[0], xray_data[1], xray_data[2]
    Ifit = (q+phi)*0.
    print 'Calculating fit... ',
    for i, ff in enumerate(fit_functions):
        print i,
        Ifit = np.add(Ifit, ff.calcSelf(q, phi+math.pi/2.)) ## add pi/2 to phi for fitting
        #print 'fitter/calculateFit/', ff.calcSelf(q, phi)
    print '\r'
    return q, phi, Ifit


def fit(fit_functions, impedance_data, heads, status):
    # get data
    q = xray_data[0]
    phi = xray_data[1]
    I = xray_data[2]

    # limit freq range #
    #freq, e1, e2 = limitRange(freq, status.fit_range, e1, e2)

    # get list of current parameters and values, and whether fixed
    all_parameter_values = []
    is_fixed_li = []
    for fit_function in fit_functions:
        all_parameter_values += [getattr(fit_function, ea) for ea in fit_function.parameters]
        is_fixed_li += fit_function.fixed
    n_params = len(all_parameter_values)

    # get bounds of each parameter
    all_parameter_bounds = []
    for fit_function in fit_functions:
        all_parameter_bounds += getattr(fit_function, 'bounds')

    # sort parameters into fixed or not fixed
    fit_parameters, fit_indices, fixed_parameters, fixed_indices = [], [], [], []
    for i in range(len(all_parameter_values)):
        if is_fixed_li[i]:
            fixed_parameters.append(all_parameter_values[i])
            fixed_indices.append(i)
        else:
            fit_parameters.append(all_parameter_values[i])
            fit_indices.append(i)

    print fit_parameters, fit_indices, fixed_parameters, fixed_indices

    # concatenate e1 and e2 together for fitting
    ff = np.concatenate((freq, freq))
    loge1e2 = np.concatenate( (np.log10(e1), np.log10(e2)) )
    
    # define fit function
    def function(f, all_parameters):
        all_parameters = list(all_parameters)
        e1_fit, e2_fit = np.zeros(f.size), np.zeros(f.size)
        for fit_function in fit_functions:
            n_parameters = len(fit_function.parameters)
            parameters = all_parameters[:n_parameters]
            all_parameters = all_parameters[n_parameters:]
            e1_fit += fit_function.functionE1(f, parameters)
            e2_fit += fit_function.functionE2(f, parameters)
        return e1_fit, e2_fit
    #def functionResidual(all_parameters, ff, loge1e2):
    #    f = ff[:ff.size/2]
    #    e1_fit, e2_fit = function(f, all_parameters)
    #    diff = loge1e2 - np.log10(np.concatenate((e1_fit, e2_fit)))
    #    return diff

    def functionResidual(fit_parameters, fit_indices, fixed_parameters, fixed_indices, n_params, bounds, ff, loge1e2):
        f = ff[:ff.size/2]
        # construct all_parameters list
        all_parameters = [None for i in range(n_params)]
        for param, i in zip(list(fit_parameters)+list(fixed_parameters), list(fit_indices)+list(fixed_indices)):
            all_parameters[i] = param
        # check if any param is outside bounds
        for p, b in zip(all_parameters, bounds):
            if p < b[0]:
                return 1e20 * b[0]-p
            if p > b[1]:
                return 1e20 * p - b[1]
        # evaluate function
        e1_fit, e2_fit = function(f, all_parameters)
        # get difference between function and experimental data
        diff = loge1e2 - np.log10(np.concatenate((e1_fit, e2_fit)))
        return diff

    best, cov, info, message, ier = leastsq(functionResidual,
                                            fit_parameters,
                                            args=(fit_indices, fixed_parameters, fixed_indices, n_params, all_parameter_bounds, ff, loge1e2),
                                            full_output=True)
    result_parameters = list(best)
    print '********Fit results:********'
    print info['nfev'], 'iterations'
    print message
    
    # put result parameters into fit functions #
    new_all_parameters = [None for i in range(n_params)]
    for ea, i in zip(result_parameters, fit_indices):
        new_all_parameters[i] = ea
    for ea, i in zip(fixed_parameters, fixed_indices):
        new_all_parameters[i] = ea
    new_fit_functions = []
    for fit_function in fit_functions:
        for param in fit_function.parameters:
            setattr(fit_function, param, new_all_parameters.pop(0))
        new_fit_functions.append(fit_function)
    return new_fit_functions








    
    
