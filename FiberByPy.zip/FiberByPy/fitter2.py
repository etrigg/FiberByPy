import numpy as np
import math
import matplotlib.pyplot as plt
import timeit
import time
import sys
import os
import classes
from decimal import Decimal
import random
import copy as cp
import scipy
from scipy import interpolate


def limitRange(data, qmin, qmax, phimin, phimax=10):
    q, phi, I = data[0], data[1], data[2]
    new_q, new_phi, new_I = [], [], []
    for i in range(len(q)):
        q_i, phi_i, I_i = q[i], phi[i], I[i]
        if (qmin <= q_i <= qmax) and (phimin <= phi_i <= phimax):
            new_q.append(q_i)
            new_phi.append(phi_i)
            new_I.append(I_i)
    return np.array([np.array(new_q), np.array(new_phi), np.array(new_I)])
            

def calcSSD(data1, data2):
    intensity1 = data1[2]
    intensity2 = data2[2]
    diffs = np.subtract(intensity1, intensity2)
    return np.sum(np.square(diffs))

def calculateFit(status, exp_data, func_exclude=-1, quiet=False):
    fit_functions, xray_data = status.fit_functions, exp_data
    q, phi, I = xray_data[0], xray_data[1], xray_data[2]
    Ifit = (q+phi)*0.
    if not quiet:
        print '              Calculating fit... ',
    for i, ff in enumerate(fit_functions):
        if not quiet:
            print i,
        if i != func_exclude:
            Ifit = np.add(Ifit, ff.calcSelf(q, phi+math.pi/2.)) ## add pi/2 to phi for fitting
    if not quiet:
        print '\r'
    return q, phi, Ifit

def fitStepper(status, fitfunc_n, no_iter):

    def pickParameter(fitfunc):
        while True:
            param_index = random.choice(range(len(fitfunc.param_names)))
            if fitfunc.fixed[param_index] is False:
                param_name = fitfunc.param_names[param_index]
                param_stepsize = fitfunc.param_stepsize[param_index]
                return param_index, param_name, param_stepsize


    starttime = timeit.default_timer()
    fitfunc = status.fit_functions[fitfunc_n]
    n_param_changes = 0
    n_consecutive_unchanged = 0 # keep track of how many consecutive times param was unchanged
    
    # limit data range to domain of fitfunc
    qmin, qmax = fitfunc.getQIntegrationLimits()
    exp_data = limitRange(status.xray_data, qmin, qmax, fitfunc.getPhiIntegrationLimits(qmin))
    
    for i in range(no_iter):
        
        # pick a random parameter and make sure it's not fixed
        param_index, param_name, param_stepsize = pickParameter(status.fit_functions[fitfunc_n])

        # calculate old fit
        fit_data = calculateFit(status, exp_data)
        param_old_value = getattr(status.fit_functions[fitfunc_n], param_name)

        # change the parameter by param_stepsize (random sign)
        step = random.choice([param_stepsize, -param_stepsize])
        setattr(status.fit_functions[fitfunc_n], param_name,
                param_old_value + step)
        new_fit_data = calculateFit(status, exp_data)
        
        # compare new and old fit
        old_ssd = calcSSD(fit_data, exp_data)
        new_ssd = calcSSD(new_fit_data, exp_data)
        
        # if fit improved, keep, otherwise revert
        if old_ssd < new_ssd:
            print '----- %s -- Fit not improved: SSD increased by %f %s (%d/%d)' % (param_name, (new_ssd/old_ssd-1)*100, '%', i+1, no_iter)
            n_consecutive_unchanged += 1
            setattr(status.fit_functions[fitfunc_n], param_name,
                    param_old_value)
        else:
            print '----- %s -- Fit improved: SSD reduced by %f %s (%d/%d)' % (param_name, 100 - (new_ssd/old_ssd)*100, '%', i+1, no_iter)
            print '      %s -- %E -> %E' % (param_name, param_old_value,
                                                 param_old_value+step)
            n_consecutive_unchanged = 0
            n_param_changes += 1

        # if params unchanged for a long time, reduce step sizes by factor of 1.5
        if n_consecutive_unchanged > len(status.fit_functions[fitfunc_n].param_names) * 10:
            print 'Reducing step sizes.'
            n_consecutive_unchanged = 0
            for i, ea in enumerate(status.fit_functions[fitfunc_n].param_stepsize):
                status.fit_functions[fitfunc_n].param_stepsize[i] = ea / 1.5
                
    print '\nSeconds per iteration:', (timeit.default_timer() - starttime) / no_iter
    print 'Number of paramter changes:', n_param_changes, '\n'


def fitDeriv(status, fitfunc_n, no_iter, quiet=False):

    def pickParameter(fitfunc):
        while True:
            param_index = random.choice(range(len(fitfunc.param_names)))
            if fitfunc.fixed[param_index] is False:
                param_name = fitfunc.param_names[param_index]
                param_stepsize = fitfunc.param_stepsize[param_index]
                return param_index, param_name, param_stepsize

    def signOfDeriv(param_old_value, deriv_coeffs):
        deriv_val = deriv_coeffs[0]*param_old_value + deriv_coeffs[1]
        return deriv_val/abs(deriv_val)

                
    starttime = timeit.default_timer()
    fitfunc = status.fit_functions[fitfunc_n]
    n_param_changes = 0
    n_consecutive_unchanged = 0 # keep track of how many consecutive times param was unchanged
    
    # limit data range to domain of fitfunc
    qmin, qmax = fitfunc.getQIntegrationLimits()
    exp_data = limitRange(status.xray_data, qmin, qmax, fitfunc.getPhiIntegrationLimits(qmin))

    qmin, qmax, phimin, phimax = tuple(status.fit_range)
    exp_data = limitRange(status.xray_data, qmin, qmax, phimin, phimax=phimax)

    for i in range(no_iter):
        
        # pick a random parameter and make sure it's not fixed
        param_index, param_name, param_stepsize = pickParameter(status.fit_functions[fitfunc_n])

        # calculate old fit
        fit_data = calculateFit(status, exp_data, quiet=quiet)
        param_old_value = getattr(status.fit_functions[fitfunc_n], param_name)

        # positive step and calculate fit
        setattr(status.fit_functions[fitfunc_n], param_name, param_old_value +param_stepsize)
        pos_step_fit_data = calculateFit(status, exp_data, quiet=quiet)
        # negative step and calculate fit
        setattr(status.fit_functions[fitfunc_n], param_name, param_old_value -param_stepsize)
        neg_step_fit_data = calculateFit(status, exp_data, quiet=quiet)

        # calc SSDs
        old_ssd = calcSSD(fit_data, exp_data)
        pos_ssd = calcSSD(pos_step_fit_data, exp_data)
        neg_ssd = calcSSD(neg_step_fit_data, exp_data)

        # get quadratic function to describe SSD vs. parameter value
        param_vals = [param_old_value - param_stepsize, param_old_value, param_old_value + param_stepsize]
        ssd_vals = [neg_ssd, old_ssd, pos_ssd]
        poly = np.polyfit(np.array(param_vals), np.array(ssd_vals), 2)
        a2, a1, a0 = tuple(poly)
        deriv_coeffs = [2*a2, a1]
        
        # if pos. curvature, set param_val to min( quadratic_minimum, param_old_value +/- 3*stepsize
        if a2 > 0:
            root = np.roots(deriv_coeffs)[0]
            if (param_old_value - 3*param_stepsize < root < param_old_value + 3*param_stepsize):
                newval = root
            elif param_old_value - 3*param_stepsize > root:
                newval = param_old_value - 3*param_stepsize
            elif param_old_value + 3*param_stepsize < root:
                newval = param_old_value + 3*param_stepsize
        # otherwise just change by stepsize
        else:
            s = signOfDeriv(param_old_value, deriv_coeffs)
            newval = param_old_value + s*param_stepsize

        # now optimize intensity
        if not quiet:
            print 'Optimizing intensity...',
        other_funcs_fit = calculateFit(status, exp_data, func_exclude=fitfunc_n, quiet=quiet)
        status.fit_functions[fitfunc_n].optimizeIntensity
        if not quiet:
            print 'done.',
        
        setattr(status.fit_functions[fitfunc_n], param_name, newval)
        print '      %s -- %E -> %E (%d/%d)' % (param_name, param_old_value, newval, i+1, no_iter)
    
    print '\nSeconds per iteration:', (timeit.default_timer() - starttime) / no_iter
    #print 'Number of paramter changes:', n_param_changes, '\n'


    
def getParamErrors(status, err_frac, fitfunc_n='all'):

    # for each parameter, calculates how much you would need to
    # change that parameter to increase by 10%
    # where the change in SSD is a fraction of the 

    exp_data = status.xray_data

    def setIfNone(param_error, index, value):
        if param_error[index] is None:
            param_error[index] = value
        return param_error
    
    if fitfunc_n == 'all':
        fitfuncs = range(len(status.fit_functions))
    else:
        fitfuncs = [fitfunc_n]
    param_errors_all_funcs = []
    for ff in fitfuncs[3:]:
        print '\n*** Now calculating error for function ', ff, ' ***'
        param_errors = []
        for i, param_name in enumerate(status.fit_functions[ff].param_names):

            param_error = [None,None]
            
            # get max of (+10% SSD and -10% SSD param values, OR just +/- step_size)
            old_fit_data = calculateFit(status, exp_data)
            param_old_value = getattr(status.fit_functions[ff], param_name)
            param_step = status.fit_functions[ff].param_stepsize[i]

            # calc fits w/ param step up and down
            setattr(status.fit_functions[ff], param_name, param_old_value + param_step)
            plusstep_fit_data = calculateFit(status, exp_data)
            setattr(status.fit_functions[ff], param_name, param_old_value - param_step)
            minusstep_fit_data = calculateFit(status, exp_data)

            # return to old value
            setattr(status.fit_functions[ff], param_name, param_old_value)

            # calculate fit w/ function intensity set to zero
            old_intensity = getattr(status.fit_functions[ff], 'intensity')
            setattr(status.fit_functions[ff], 'intensity', 0)
            nofunc_fit_data = calculateFit(status, exp_data)
            setattr(status.fit_functions[ff], 'intensity', old_intensity)

            # get SSDs and diff SSDs
            old_sqssd = math.sqrt(calcSSD(old_fit_data, exp_data))
            plusstep_sqssd = math.sqrt(calcSSD(plusstep_fit_data, exp_data))
            minusstep_sqssd = math.sqrt(calcSSD(minusstep_fit_data, exp_data))
            nofunc_sqssd = math.sqrt(calcSSD(nofunc_fit_data, exp_data))

            # normalize the sqssd by the sqssd with NO fit function
            old_sqssd, plusstep_sqssd, minusstep_sqssd = old_sqssd/nofunc_sqssd, plusstep_sqssd/nofunc_sqssd, minusstep_sqssd/nofunc_sqssd

            print 'minus sqssd, old sqssd, plus sqssd'
            print minusstep_sqssd, old_sqssd, plusstep_sqssd
            
            # print error if fit not optimized
            if plusstep_sqssd < old_sqssd:
                print 'Error! Fit not optimized: increase %s' % (param_name)
                param_error = setIfNone(param_error, 1, 1e6)
            elif minusstep_sqssd < old_sqssd:
                print 'Error! Fit not optimized: decrease %s' % (param_name)
                param_error = setIfNone(param_error, 0, 1e6)

            else:
                # calculate quadratic coeffs describing the 3 points (sqssd vs param) 
                param_vals = [param_old_value - param_step, param_old_value, param_old_value + param_step]
                sqssd_vals = [minusstep_sqssd, old_sqssd, plusstep_sqssd]
                poly = np.polyfit(param_vals, sqssd_vals, 2)
                print poly
                a2, a1, a0 = tuple(poly)
                arg = a1**2 - 4*a2*(a0-(1+err_frac)*old_sqssd)
                if arg < 0:
                    print '----- Error: arg < 0 -----'
                else:
                    lowerbound_param = (-a1 - math.sqrt(arg))/(2.*a2)
                    upperbound_param = (-a1 + math.sqrt(arg))/(2.*a2)
                    print '%s=x fit:' % (param_name), 'SSD = %2.2fx^2 + %2.2fx + %2.2f' % (tuple(poly))
                    print param_name, param_old_value
                    print '(+', upperbound_param, '/', lowerbound_param, ')'

            
    
        





