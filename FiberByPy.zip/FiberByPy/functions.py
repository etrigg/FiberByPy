import numpy as np
import scipy
from scipy import special
from scipy import interpolate
import matplotlib.pyplot as plt
import math
import cmath
import datetime
import time
import sys
import os


WAVELENGTH = .73 # angstroms


#### Math ####

def fraserCorrection(q, phi):
    wl_factor = WAVELENGTH/(4*math.pi)
    func3 = math.sqrt( (q**2 - wl_factor**2 * q**4) / (1 + 1/(math.tan(phi)**2)) )
    func2 = wl_factor * q**2
    func1 = func3/math.tan(phi)
    return math.atan2(func3, math.sqrt(func1**2 + func2**2))

def getMaierSaupeEqKernel(phi, p, phiPrime): # returns a function describing the kernel
    # phi is np array
    # phiPrime is np array

    def maierSaupeKernelFunction(phi, phiPrime, p, c):
        x = np.cos(phi)*np.cos(phiPrime)
        y = np.sin(phi)*np.sin(phiPrime)
        x2 = np.square(x)
        xy = x*y
        y2 = np.square(y)
        factor1 = c * np.exp(p* (x2 + y2/2.) )
        term1 = scipy.special.iv(0, 2.*p*xy) * scipy.special.iv(0, p*y2/2.)
        term2 = 0
        for i in range(1,20):
            term2 += 2. * scipy.special.iv(2*i, 2.*p*xy) * scipy.special.iv(i, p*y2/2)
        factor2 = term1 + term2
        return abs((factor1*factor2).real)

    phi_key = sorted(list(set(phi)))

    c = 2. * cmath.sqrt(p/math.pi) / scipy.special.erfi(cmath.sqrt(p))
    kernel_interp_li = []
    for i in range(len(phi_key)):
        kernel = maierSaupeKernelFunction(phi_key[i], phiPrime, p, c)
        kernel_interp = scipy.interpolate.interp1d(phiPrime, kernel, kind='quadratic')
        kernel_interp_li.append(kernel_interp)
    return phi_key, kernel_interp_li

    


#### Utility ####

def getDataFromFiles(filenames, phis):

    q = None

    for i, f in enumerate(filenames):
        data = np.loadtxt(f)
        len_data = data.shape[0]
        if q is None:
            q = np.zeros(len_data*len(phis))
            I = np.zeros(len_data*len(phis))
            phi = np.zeros(len_data*len(phis))
        data = np.transpose(data)
        q_f, I_f, res_f = data[0], data[1], data[2]
        q[i*len_data:(i+1)*len_data] = q_f
        I[i*len_data:(i+1)*len_data] = I_f
        phi[i*len_data:(i+1)*len_data] = np.full(len_data, phis[i])

    ### apply fraser correction to phi values
    for i in range(q.shape[0]):
        phi[i] = fraserCorrection(q[i], phi[i])

    return np.array([q, phi, I])

    
