import numpy as np
import matplotlib.pyplot as plt
import math
import datetime
import time
import sys
import os
import plotter
import fitter2
import functions
from classes import *

        

### possible commands ###
# open <filebasepath> <range(__)> <range(__)>     -- opens files (see example)
# plot                              -- plots data, or plots data + current fit (wopen opens fig in windows photo viewer)
# plotdiff                          -- plots exp/fit figure, and difference figure
# saveplot filename data/fit <wopen>     -- plots data and saves with specified filename
# func <action> <arg>  -- adds/removes a fit function or fix/unfix
#                                           <action>=add, rm
#					    <arg>=func type for add, or func number for rm
# change <fitfunc_n> <parameter_n> <newvalue>  -- manually change a fitting parameter value
# changeall <fitfunc_n> <newvalue> <newvalue> ...  -- change all parameters in a function at once
# changestep <fitfunc_n> <parameter> <newstep> -- manually change parameter step size
# vrange <vmin> <vmax>              -- change color range
# setcalclimit <fitfunc_n> <x> <value> -- set limit of calculation of fitfunc_n if type = peaktype1. x = qmin, qmax, or phimin.
# setexprange <qmin> <qmax>         -- set range of experimental (and fit) data (impacts plot range)
# printbounds                       -- print ranges of all parameters in all functions
# fit <type> <func_n> <no_iter>     -- run the fit (type = stepper or deriv)
# fitm <type> <func_n list> <no_iter> -- fits each func_n in func_n list (comma-sepatated, no spaces)(type = stepper or deriv)
# fita <type> <func_n:func_n:...> <no_iter> -- alternates between all func_n functions (<no_iter> iterations per function) 
# fitlim <qlo> <qhi> <philo> <phihi> -- set fitting range (x axis only)
# plot_fitlim                       -- toggle whether to trace fit limits on plot
# printssd                          -- print ssd for current fit
# fix <fitfunc_n> <parameter>       -- toggle whether to fix a fitting parameter or allow fit
# q                                 -- quit program
# savestate <filename>              -- save current state to file
# loadstate <filename> <nofile>       -- open saved state, include "nofile" if not open exp
# readcmds <cmd_filename>           -- reads a series of commands from a file (one cmd per line)


def processCommand(cmd, status):
    cmd0 = cmd.split()[0]
    
    if cmd0 == 'open':      ##################################################################################
        #f = open('p21aa-22_sym_data/p21aa-22_chi0.0-2.0.txt')
        #print f
        #print f.read().splitlines()[0]
        cmd = cmd.split()
        file_basename = cmd[1]
        exec('phi1_li = %s' % cmd[2])
        exec('phi2_li = %s' % cmd[3])
        #phi1_li = range(0,90,2)
        #phi2_li = range(2,92,2)
        #files = ['p21aa-32_sym/p21aa-32_sym_chi%d.0-%d.0.txt' % (phi1, phi2) for phi1, phi2 in zip(phi1_li,phi2_li)]
        files = [file_basename + '_chi%d.0-%d.0.txt' % (phi1, phi2) for phi1, phi2 in zip(phi1_li,phi2_li)]
        phi_li = [.5*(phi1+phi2)*math.pi/180. for phi1, phi2 in zip(phi1_li,phi2_li)]
        print files[0]
        q, phi, I = functions.getDataFromFiles(files, phi_li)
        status.xray_data = np.array([q, phi, I])
        status.cur_files = ' '.join(cmd[1:])
        print 'Loaded data.'

        
    elif cmd0 == 'plot' or cmd0 == 'saveplot' or cmd0 == 'p':    ############################################
        plotter.producePlot(status, cmd)
    elif cmd0 == 'plotdiff':
        plotter.produceDiffPlot(status, cmd)


    elif cmd0 == 'func':  ##################################################################################
        cmd0, action, item = tuple(cmd.split())
        if action == 'add':
            if item == 'peaktype1':
                newfunc = peaktype1()
            elif item == 'peaktype1eq':
                newfunc = peaktype1eq()
            elif item == 'peaktype6eq':
                newfunc = peaktype6eq()
            elif item == 'peaktype7eq':
                newfunc = peaktype7eq()
            elif item == 'flatbgnd':
                newfunc = flatbgnd()
            elif item == 'amorphhaloL':
                newfunc = amorphhaloL()
            else:
                print 'Function not recognized'
                return None
            status.fit_functions.append(newfunc)
        elif action == 'rm':
            del status.fit_functions[int(item)]
        elif action == 'fix':
            for i in range(len(status.fit_functions[int(item)].fixed)):
                status.fit_functions[int(item)].fixed[i] = True
        elif action == 'unfix':
            for i in range(len(status.fit_functions[int(item)].fixed)):
                status.fit_functions[int(item)].fixed[i] = False


    elif cmd0 == 'change':
        cmd0, fitfunc_n, param, newvalue = tuple(cmd.split())
        fitfunc_n, newvalue = int(fitfunc_n), float(newvalue)
        setattr(status.fit_functions[fitfunc_n], param, newvalue)

    elif cmd0 == 'changeall':
        cmd = cmd.split()
        fitfunc_n = int(cmd[1])
        for i, param in enumerate(status.fit_functions[fitfunc_n].param_names):
            if len(cmd) != len(status.fit_functions[fitfunc_n].param_names)+2:
                print 'Invalid function'
                return None
            setattr(status.fit_functions[fitfunc_n], param, float(cmd[i+2]))

    elif cmd0 == 'changestep':
        cmd = cmd.split()
        cmd0, fitfunc_n, param, new_step = tuple(cmd)
        fitfunc_n = int(fitfunc_n)
        param_no = status.fit_functions[fitfunc_n].param_names.index(param)
        print fitfunc_n, param, 'old value:', status.fit_functions[fitfunc_n].param_stepsize[param_no]
        status.fit_functions[fitfunc_n].param_stepsize[param_no] = float(new_step)
        print '      ...changed to',  new_step
        
        
    elif cmd0 == 'fix':
        cmd0, fitfunc_n, param = tuple(cmd.split())
        fitfunc_n = int(fitfunc_n)
        index = status.fit_functions[fitfunc_n].param_names.index(param)
        status.fit_functions[int(fitfunc_n)].fixed[index] = not status.fit_functions[fitfunc_n].fixed[index]
        

    elif cmd0 == 'setbounds':
        cmd0, fitfunc_n, param, newmin, newmax = tuple(cmd.split())
        param_index = status.fit_functions[int(fitfunc_n)].parameters.index(param)
        status.fit_functions[int(fitfunc_n)].bounds[param_index] = [newmin, newmax]

    elif cmd0 == 'printbounds':
        print 'Parameter ranges:'
        for i, fitfunc in enumerate(status.fit_functions):
            print '%d. %s' % (i, fitfunc.printBounds())

    elif cmd0 == 'setcalclimit':
        tmp, fitfunc_n, x, val = tuple(cmd.split())
        if x == 'qmin':
            status.fit_functions[int(fitfunc_n)].override_qmin = float(val)
        elif x == 'qmax':
            status.fit_functions[int(fitfunc_n)].override_qmax = float(val)
        elif x == 'phimin':
            status.fit_functions[int(fitfunc_n)].override_phimin = float(val)

    elif cmd0 == 'setexprange':
        tmp, qmin, qmax = tuple(cmd.split())
        qmin, qmax = float(qmin), float(qmax)
        new_q, new_phi, new_I = [], [], []
        for i in range(status.xray_data.shape[1]):
            if qmin < status.xray_data[0][i] < qmax:
                new_q.append(status.xray_data[0][i])
                new_phi.append(status.xray_data[1][i])
                new_I.append(status.xray_data[2][i])
        status.xray_data = np.array([new_q, new_phi, new_I])

    elif cmd0 == 'fit':
        tmp, fit_type, fitfunc_n, no_iter = tuple(cmd.split())
        if fit_type == 'stepper':
            fitter2.fitStepper(status, int(fitfunc_n), int(no_iter))
        elif fit_type == 'deriv':
            fitter2.fitDeriv(status, int(fitfunc_n), int(no_iter))

    elif cmd0 == 'fitm':
        tmp, fit_type, fitfunc_n_li, no_iter = tuple(cmd.split(' '))
        fitfunc_n_li = [int(ea) for ea in fitfunc_n_li.split(',')]
        if ',' in no_iter:
            no_iter_li = [int(ea) for ea in no_iter.split(',')]
        else:
            no_iter_li = [int(no_iter) for ea in fitfunc_n_li]
        for no_iter, fitfunc_n in zip(no_iter_li, fitfunc_n_li):
            print '************ Now fitting fitfunc %d *************' % (fitfunc_n)
            if fit_type == 'stepper':
                fitter2.fitStepper(status, int(fitfunc_n), int(no_iter))
            elif fit_type == 'deriv':
                fitter2.fitDeriv(status, int(fitfunc_n), int(no_iter))

    elif cmd0 == 'fita':
        tmp, fit_type, fitfunc_n_li, no_iter = tuple(cmd.split())
        fitfunc_n_li = fitfunc_n_li.split(':')
        for i in range(int(no_iter)):
            print '---- (%d/%s) ----' % (i, no_iter)
            for fitfunc_n in fitfunc_n_li:
                print 'Func %s' % (fitfunc_n),
                if fit_type == 'stepper':
                    fitter2.fitStepper(status, int(fitfunc_n), 1)
                elif fit_type == 'deriv':
                    fitter2.fitDeriv(status, int(fitfunc_n), 1)
                

    elif cmd0 == 'fitlim':
        cmd0, q_lo, q_hi, phi_lo, phi_hi = cmd.split()
        status.fit_range = (float(q_lo),float(q_hi),float(phi_lo),float(phi_hi))

    elif cmd0 == 'plot_fitlim':
        status.plot_fitlim = not status.plot_fitlim

    elif cmd0 == 'fiterr':
        fitter2.getParamErrors(status, .1)

    elif cmd0 == 'savestate': ##################################################################################
        cmd = cmd.split()
        if len(cmd) > 1:
            filename = cmd[1]
        else:
            filename = 'log'
        f = open('%s.txt' % (filename), 'w')
        f.write(status.saveStatus())
        f.close()
        print 'State saved as %s.txt' % (filename)

    elif cmd0 == 'loadstate': ##################################################################################
        if len(cmd.split()) == 1:
            filepath = askopenfilename()
        elif len(cmd.split()) == 2:
            cmd0, filepath = tuple(cmd.split())
            nofile = False
        else:
            cmd0, filepath = tuple(cmd.split()[:2])
            nofile = True
        status.getStatusFromFile(filepath+'.txt', nofile)
        status.printStatus()
        
        print 'State loaded from file "%s"' % (filepath)

    elif cmd0 == 'readcmds':
        tmp, filename = tuple(cmd.split())
        f = open(filename, 'r')
        s = f.readlines()
        for line in s:
            print '\n*CMD: %s\n' % (line)
            processCommand(line, status)

    elif cmd0 == 'vrange': ####################################################################################
        tmp, vmin, vmax = tuple(cmd.split())
        status.vmin = float(vmin)
        status.vmax = float(vmax)

    elif cmd0 == 'printssd':
        print 'SSD =',
        print fitter2.calcSSD(status.xray_data, fitter2.calculateFit(status, status.xray_data))

    elif cmd0 == 'q':       ##################################################################################
        return 'q'

    else:                   ##################################################################################
        print 'No such command: %s' % (cmd)

    if cmd0 in ['fit', 'fitm', 'fita', 'open', 'func', 'change', 'changeall', 'fix']:
        status.printStatus()

global status
status = program_status()

# loop #

cmds = [
]
'''

    
    'loadstate p21aa-32_sym_results/peaks_all_peak7eq_maier-saupe-best',
    'setexprange .15 .5',
    'setcalclimit 1 qmin .1',
    'setcalclimit 1 qmax .6',
    'vrange 0 1.2e4',
    'saveplot 32.png',
    
    'loadstate p21aa-0-1_sym_results/peak1-paramfromframe5_upturn_amorph',
    'setexprange .15 .5',
    'setcalclimit 1 qmin .1',
    'setcalclimit 1 qmax .6',
    'vrange 0 1.2e4',
    'saveplot 0-1.png',
    
    'loadstate p21aa-4_sym_results/peak1_1',
    'setexprange .15 .5',
    'setcalclimit 1 qmin .1',
    'setcalclimit 1 qmax .6',
    'vrange 0 1.2e4',
    'saveplot 4.png',
    
    'loadstate p21aa-10_sym_results/peak1_1',
    'setexprange .15 .5',
    'setcalclimit 1 qmin .1',
    'setcalclimit 1 qmax .6',
    'vrange 0 1.2e4',
    'saveplot 10.png'
    
    ]

'''
for cmd in cmds:
    print '\n*CMD: %s\n' % (cmd)
    processCommand(cmd, status)
status.printStatus()

while True:
    cmd = raw_input('cmd:')
    status.command_history.append(cmd)
    try:
        cmd = processCommand(cmd, status)
    except:
        print 'AN ERROR OCCURRED.'
        print sys.exc_info()
    if cmd == 'q':
        sys.exit()
        
