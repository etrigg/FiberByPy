import numpy as np
import matplotlib.pyplot as plt
import datetime
import time
import sys
import math
import fitter


def plotPolarImage(data, ax, quadrents, status, plot):
    
    q, phi, I = data[0], data[1], data[2]
    for i in range(phi.shape[0]):
        if phi[i] < 2. * math.pi/180.:
            phi[i] = 0
    vmin, vmax = status.vmin, status.vmax
    if plot == 'diff' and vmin is not None and vmax is not None:
        vmin, vmax = status.vrangeDiff()
    cmap_selection = {'exp':status.cmap, 'fit':status.cmap,
                      'fit_diff':status.cmap_diff, 'diff':status.cmap_diff}
    cmap = cmap_selection[plot]

    # find len(q) for each wedge
    len_q = q.shape[0]
    for i in range(1,q.shape[0]):
        if q[i-1] > q[i]:
            len_q = i
            break

    n_wedges = q.shape[0]/len_q
    q_2d = q.reshape((n_wedges, len_q))
    phi_2d = phi.reshape((n_wedges, len_q))
    I_2d = I.reshape((n_wedges, len_q))

    if quadrents==[1,3]:
        phi1_2d = phi_2d
        phi2_2d = phi_2d + math.pi
    if quadrents==[2,4]:
        phi1_2d = -1.*phi_2d + math.pi
        phi2_2d = -1.*phi_2d + 2.*math.pi
    
    cm_object = ax.pcolormesh(phi1_2d, q_2d, I_2d, cmap=cmap, vmin=vmin, vmax=vmax)

    if status.plot_fitlim: # trace fit limits on polar plot
        qmin, qmax, phimin, phimax = tuple(status.fit_range)
        ax.plot([phimin, phimin], [qmin, qmax], 'k', linewidth=.5)
        ax.plot([phimax, phimax], [qmin, qmax], 'k', linewidth=.5)
        ax.plot(np.linspace(phimin, phimax, 100), np.full(100, qmin), 'k', linewidth=.5)
        ax.plot(np.linspace(phimin, phimax, 100), np.full(100, qmax), 'k', linewidth=.5)
        
    
    ax.pcolormesh(phi2_2d, q_2d, I_2d, cmap=cmap, vmin=vmin, vmax=vmax)
    ax.set_yticklabels([])
    ax.set_xticklabels([])
    return cm_object


def plotIvsQ(exp_data, fit_data, ax):

    # find len(q) for each wedge
    q = exp_data[0]
    len_q = q.shape[0]
    for i in range(1,q.shape[0]):
        if q[i-1] > q[i]:
            len_q = i
            break
    n_wedges = q.shape[0]/len_q

    # meridian
    q_exp, I_exp = exp_data[0][0:len_q], exp_data[2][0:len_q]
    ax.plot(q_exp, I_exp, 'k-')
    q_fit, I_fit = fit_data[0][0:len_q], fit_data[2][0:len_q]
    ax.plot(q_fit, I_fit, 'r-')

    max_I_exp = np.amax(I_exp)

    # equator (offset by max_I_exp)
    start_i = (n_wedges-1)*len_q
    end_i = (n_wedges)*len_q
    q_exp, I_exp = exp_data[0][start_i:end_i], exp_data[2][start_i:end_i]
    ax.plot(q_exp, I_exp + max_I_exp, 'k-')
    q_fit, I_fit = fit_data[0][start_i:end_i], fit_data[2][start_i:end_i]
    ax.plot(q_fit, I_fit + max_I_exp, 'r-')

    ax.set_xlabel('q [$\AA^{-1}$]')
    ax.set_ylabel('I [a.u.]')    
    

def plotMain(status, filename, fit_data=None):
    xray_data = status.xray_data
    plt_commands = status.plt_commands

    fig = plt.figure(figsize=(11,4.5))
    ax1 = fig.add_subplot(1,3,1, projection='polar')
    ax2 = fig.add_subplot(1,3,2, projection='polar')
    ax3 = fig.add_subplot(1,3,3)
    
    #fig, axarr = plt.subplots(nrows=1, ncols=3, figsize=(11,5), subplot_kw=dict(projection='polar'))
    #ax1, ax2, ax3 = tuple(axarr)

    vrange = (0,1e4)

    cm_object1 = plotPolarImage(xray_data, ax1, [1,3], status, plot='exp')
    if fit_data:
        plotPolarImage(fit_data, ax1, [2,4], status, plot='fit')

    diff_vrange = ( -sum(vrange)/2., sum(vrange)/2. )

    if fit_data:
        I_exp = xray_data[2]
        I_fit = fit_data[2]
        I_diff = np.subtract(I_exp, I_fit)
        I_diff2 = np.subtract(I_fit, I_exp)
        diff_data = np.array([xray_data[0], xray_data[1], I_diff])
        diff2_data = np.array([xray_data[0], xray_data[1], I_diff2])
        cm_object2 = plotPolarImage(diff_data, ax2, [1,3], status, plot='diff')
        plotPolarImage(fit_data, ax2, [2,4], status, plot='fit_diff')

     # add colorbar
    fig.colorbar(cm_object1, ax=ax1, shrink=.95, ticks=[], fraction=0.046, pad=0.04)
    if fit_data:
        fig.colorbar(cm_object2, ax=ax2, shrink=.95, ticks=[], fraction=0.046, pad=0.04)
    ax2.set_title('red: fit < exp')

    if fit_data:
        plotIvsQ(xray_data, fit_data, ax3)

    plt.tight_layout()
    plt.savefig(filename,dpi=400)
    plt.close('all')


def plotDiff(status, filename, fit_data=None):
    xray_data = status.xray_data
    plt_commands = status.plt_commands
    
    fig, axarr = plt.subplots(nrows=1, ncols=2, figsize=(8,5), subplot_kw=dict(projection='polar'))
    ax1, ax2 = tuple(axarr)

    vrange = (0,1e4)

    cm_object1 = plotPolarImage(xray_data, ax1, [1,3], status, plot='exp')
    if fit_data:
        plotPolarImage(fit_data, ax1, [2,4], status, plot='fit')

    diff_vrange = ( -sum(vrange)/2., sum(vrange)/2. )

    if fit_data:
        I_exp = xray_data[2]
        I_fit = fit_data[2]
        I_diff = np.absolute(np.subtract(I_exp, I_fit))
        diff_data = np.array([xray_data[0], xray_data[1], I_diff])
        cm_object2 = plotPolarImage(diff_data, ax2, [1,3], status, plot='fit')
        plotPolarImage(diff_data, ax2, [2,4], status, plot='fit')

     # add colorbar
    fig.colorbar(cm_object1, ax=ax1, shrink=.95, ticks=[], fraction=0.046, pad=0.04)
    if fit_data:
        fig.colorbar(cm_object2, ax=ax2, shrink=.95, ticks=[], fraction=0.046, pad=0.04)
    #ax2.set_title('red: fit < exp')
    plt.savefig(filename,dpi=400)
    plt.close('all')



def producePlot(status, cmd):
    
    filename = 'tmp.png'
    if cmd and cmd.split()[0] == 'saveplot':
        filename = cmd.split()[1]
    fit_data = None
    if len(status.fit_functions) > 0:
        fit_data = fitter.calculateFit(status.fit_functions, status.xray_data, status)
    plotMain(status, filename, fit_data=fit_data)


def produceDiffPlot(status, cmd):
    filename = 'tmp_diff.png'
    if cmd and cmd[0] == 'saveplot':
        filename = cmd.split()[1]
    fit_data = None
    if len(status.fit_functions) > 0:
        fit_data = fitter.calculateFit(status.fit_functions, status.xray_data, status)
    plotDiff(status, filename, fit_data=fit_data)
    

